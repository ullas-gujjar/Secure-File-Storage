import os

def split_file(filepath, chunk_size=32*1024):  # 32 KB chunks
    chunks = []
    with open(filepath, 'rb') as f:
        while True:
            chunk = f.read(chunk_size)
            if not chunk:
                break
            chunks.append(chunk)
    return chunks