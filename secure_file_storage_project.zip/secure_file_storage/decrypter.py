from cryptography.hazmat.primitives.asymmetric import padding
from cryptography.hazmat.primitives import serialization, hashes
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
from cryptography.hazmat.backends import default_backend
import json, base64, tempfile, os

def decrypt_package(encrypted_package, private_key_pem):
    # Load private key
    private_key = serialization.load_pem_private_key(
        private_key_pem.encode('utf-8'), password=None, backend=default_backend()
    )
    
    # Decode package
    package = json.loads(base64.b64decode(encrypted_package).decode('utf-8'))
    encrypted_data = base64.b64decode(package['encrypted_data'])
    iv = base64.b64decode(package['iv'])
    encrypted_aes_key = base64.b64decode(package['encrypted_aes_key'])
    
    # Decrypt AES key with RSA private key
    aes_key = private_key.decrypt(
        encrypted_aes_key,
        padding.OAEP(mgf=padding.MGF1(algorithm=hashes.SHA256()), algorithm=hashes.SHA256(), label=None)
    )
    
    # Decrypt data with AES
    cipher = Cipher(algorithms.AES(aes_key), modes.CBC(iv), backend=default_backend())
    decryptor = cipher.decryptor()
    decrypted_padded = decryptor.update(encrypted_data) + decryptor.finalize()
    data_json = decrypted_padded.rstrip(b'\0')  # Remove padding
    data = json.loads(data_json.decode('utf-8'))
    
    # Extract text and file
    text = data['text']
    file_data = base64.b64decode(data['file'])
    
    # Save file to temp
    temp_file = tempfile.NamedTemporaryFile(delete=False)
    temp_file.write(file_data)
    temp_file.close()
    
    return text, temp_file.name