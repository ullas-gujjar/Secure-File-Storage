// script.js

// -----------------------------
// Theme toggle
// -----------------------------
function initThemeToggle() {
    const html = document.documentElement;
    const toggleBtn = document.getElementById('theme-toggle');
    if (!toggleBtn) return;

    const moonIcon = toggleBtn.querySelector('[data-theme-icon="moon"]');
    const sunIcon = toggleBtn.querySelector('[data-theme-icon="sun"]');

    // Apply stored theme on load
    const storedTheme = localStorage.getItem('theme');
    if (storedTheme === 'dark') {
        html.classList.add('dark');
    } else if (storedTheme === 'light') {
        html.classList.remove('dark');
    }

    function updateIcons() {
        const isDark = html.classList.contains('dark');
        if (moonIcon && sunIcon) {
            if (isDark) {
                moonIcon.classList.add('hidden');
                sunIcon.classList.remove('hidden');
            } else {
                sunIcon.classList.add('hidden');
                moonIcon.classList.remove('hidden');
            }
        }
    }

    updateIcons();

    toggleBtn.addEventListener('click', () => {
        html.classList.toggle('dark');
        const isDark = html.classList.contains('dark');
        localStorage.setItem('theme', isDark ? 'dark' : 'light');
        updateIcons();
    });
}

// -----------------------------
// Upload progress helper
// -----------------------------
function initUploadProgress(formId, progressContainerId, progressBarId, progressLabelId) {
    const form = document.getElementById(formId);
    if (!form) return;

    const progressContainer = document.getElementById(progressContainerId);
    const progressBar = document.getElementById(progressBarId);
    const progressLabel = document.getElementById(progressLabelId);
    const submitBtn = form.querySelector('button[type="submit"]');

    form.addEventListener('submit', () => {
        if (progressContainer) {
            progressContainer.classList.remove('hidden');
        }
        if (submitBtn) {
            submitBtn.disabled = true;
        }

        // Simple fake front-end progress animation
        let value = 0;
        const interval = setInterval(() => {
            value += 10;
            if (value > 90) value = 90; // stop at 90%, server completion will finish the page load
            if (progressBar) {
                progressBar.style.width = value + '%';
            }
            if (progressLabel) {
                progressLabel.textContent = value + '%';
            }
        }, 250);

        // Clear interval on navigation/unload
        window.addEventListener('beforeunload', () => clearInterval(interval));
    });
}

// -----------------------------
// Text encryption helpers
// -----------------------------
async function encryptText() {
    const plaintextInput = document.getElementById('plaintext');
    const resultEl = document.getElementById('encrypt-result');

    if (!plaintextInput || !resultEl) return;

    const plaintext = plaintextInput.value.trim();
    if (!plaintext) {
        resultEl.textContent = 'Please enter text to encrypt.';
        return;
    }

    try {
        const response = await fetch('/encrypt_text', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ plaintext })
        });

        if (!response.ok) {
            throw new Error('Request failed');
        }

        const data = await response.json();
        resultEl.innerHTML = `Encrypted: ${data.encrypted}<br>Key: ${data.key}`;
    } catch (error) {
        console.error('Error:', error);
        resultEl.textContent = 'An error occurred during encryption.';
    }
}

async function decryptText() {
    const encryptedInput = document.getElementById('encrypted');
    const keyInput = document.getElementById('key');
    const resultEl = document.getElementById('decrypt-result');

    if (!encryptedInput || !keyInput || !resultEl) return;

    const encrypted = encryptedInput.value.trim();
    const key = keyInput.value.trim();

    if (!encrypted || !key) {
        resultEl.textContent = 'Please provide both encrypted text and key.';
        return;
    }

    try {
        const response = await fetch('/decrypt_text', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ encrypted, key })
        });

        if (!response.ok) {
            throw new Error('Request failed');
        }

        const data = await response.json();
        resultEl.innerHTML = `Plaintext: ${data.plaintext}`;
    } catch (error) {
        console.error('Error:', error);
        resultEl.textContent = 'An error occurred during decryption.';
    }
}

// -----------------------------
// Initialize on page load
// -----------------------------
document.addEventListener('DOMContentLoaded', () => {
    initThemeToggle();

    // Sender upload progress
    initUploadProgress('upload-form', 'progress', 'progress-bar', 'progress-label');

    // You can add more per-page initializers here if needed
});
