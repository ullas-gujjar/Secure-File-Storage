from cryptography.hazmat.primitives.asymmetric import rsa, padding
from cryptography.hazmat.primitives import serialization, hashes
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
from cryptography.hazmat.backends import default_backend
import os, json, base64

def encrypt_file_and_text(filepath, text):
    # Generate AES key
    aes_key = os.urandom(32)
    iv = os.urandom(16)
    
    # Generate RSA key pair
    private_key = rsa.generate_private_key(public_exponent=65537, key_size=2048, backend=default_backend())
    public_key = private_key.public_key()
    
    # Read file
    with open(filepath, 'rb') as f:
        file_data = f.read()
    
    # Combine file and text as JSON
    data = {'file': base64.b64encode(file_data).decode('utf-8'), 'text': text}
    data_json = json.dumps(data).encode('utf-8')
    
    # Encrypt data with AES
    cipher = Cipher(algorithms.AES(aes_key), modes.CBC(iv), backend=default_backend())
    encryptor = cipher.encryptor()
    padded_data = data_json + b'\0' * (16 - len(data_json) % 16)  # Simple padding
    encrypted_data = encryptor.update(padded_data) + encryptor.finalize()
    
    # Encrypt AES key with RSA public key
    encrypted_aes_key = public_key.encrypt(
        aes_key,
        padding.OAEP(mgf=padding.MGF1(algorithm=hashes.SHA256()), algorithm=hashes.SHA256(), label=None)
    )
    
    # Package: encrypted_data + iv + encrypted_aes_key
    package = {
        'encrypted_data': base64.b64encode(encrypted_data).decode('utf-8'),
        'iv': base64.b64encode(iv).decode('utf-8'),
        'encrypted_aes_key': base64.b64encode(encrypted_aes_key).decode('utf-8')
    }
    encrypted_package = base64.b64encode(json.dumps(package).encode('utf-8')).decode('utf-8')
    
    # Serialize private key for download
    private_key_pem = private_key.private_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PrivateFormat.PKCS8,
        encryption_algorithm=serialization.NoEncryption()
    ).decode('utf-8')
    
    return encrypted_package, private_key_pem