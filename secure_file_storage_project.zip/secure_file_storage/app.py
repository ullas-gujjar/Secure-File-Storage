import os
import secrets
import secrets
from io import BytesIO
from datetime import datetime
from dotenv import load_dotenv

load_dotenv()  # Load environment variables from .env file

from flask import (
    Flask,
    render_template,
    request,
    redirect,
    url_for,
    flash,
    send_file,
    flash,
    send_file,
    session,
)
from flask_mail import Mail, Message
from flask_sqlalchemy import SQLAlchemy
from flask_login import (
    LoginManager,
    login_user,
    logout_user,
    login_required,
    current_user,
    UserMixin,
)
from werkzeug.security import generate_password_hash, check_password_hash

# Cryptography
from cryptography.hazmat.primitives import hashes, padding as sym_padding
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
from cryptography.hazmat.backends import default_backend

# App & DB setup

BASE_DIR = os.path.abspath(os.path.dirname(__file__))

app = Flask(__name__)
app.config["SECRET_KEY"] = "change-this-secret-key"  # change for production
app.config["SQLALCHEMY_DATABASE_URI"] = "sqlite:///" + os.path.join(BASE_DIR, "secure_storage.db")
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False

# Flask-Mail Configuration (Use environment variables or defaults for testing)
app.config["MAIL_SERVER"] = os.environ.get("MAIL_SERVER", "smtp.gmail.com")
app.config["MAIL_PORT"] = int(os.environ.get("MAIL_PORT", 587))
app.config["MAIL_USE_TLS"] = os.environ.get("MAIL_USE_TLS", "true").lower() == "true"
app.config["MAIL_USERNAME"] = os.environ.get("MAIL_USERNAME", "your-email@example.com")
app.config["MAIL_PASSWORD"] = os.environ.get("MAIL_PASSWORD", "your-email-password")
app.config["MAIL_DEFAULT_SENDER"] = os.environ.get("MAIL_DEFAULT_SENDER", app.config["MAIL_USERNAME"])


mail = Mail(app)

# Check for default email configuration
with app.app_context():
    if app.config["MAIL_USERNAME"] == "your-email@example.com" or \
       app.config["MAIL_USERNAME"] == "your-email@gmail.com" or \
       app.config["MAIL_PASSWORD"] == "your-email-password" or \
       app.config["MAIL_PASSWORD"] == "your-app-password":
        print("\n" + "="*60)
        print(" WARNING: Email credentials are still set to defaults!")
        print(" Email notifications will NOT work until you update .env")
        print(" Edit c:\\Users\\ULLAS\\OneDrive\\Desktop\\project\\secure_file_storage\\.env")
        print("="*60 + "\n")

db = SQLAlchemy(app)

login_manager = LoginManager(app)
login_manager.login_view = "login"

# Models

class User(db.Model, UserMixin):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(120), nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password = db.Column(db.String(255), nullable=False)
    role = db.Column(db.String(20), default="sender")  # "sender" or "receiver"

    # RSA keys are no longer stored or used

class EncryptedData(db.Model):
    __tablename__ = "encrypted_data"

    id = db.Column(db.Integer, primary_key=True)
    filename = db.Column(db.String(255))
    file_data = db.Column(db.LargeBinary)          # AES-encrypted file bytes
    text_encrypted = db.Column(db.LargeBinary)     # AES-encrypted text message
    
    # Password-based encryption fields
    aes_key_wrapped = db.Column(db.LargeBinary)    # AES key wrapped with derived key
    salt = db.Column(db.LargeBinary)               # Salt for KDF
    wrapping_iv = db.Column(db.LargeBinary)        # IV for wrapping the key
    
    iv = db.Column(db.LargeBinary)                 # AES IV for file/text encryption
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    sender_id = db.Column(db.Integer, db.ForeignKey("user.id"))
    sender = db.relationship("User", backref="encrypted_items")

# Login manager

@login_manager.user_loader
def load_user(user_id):
    # SQLAlchemy 2.x–compatible
    return db.session.get(User, int(user_id))

# Crypto helpers

def derive_key(password: str, salt: bytes) -> bytes:
    """
    Derive a 32-byte (256-bit) key from the password using PBKDF2-HMAC-SHA256.
    """
    kdf = PBKDF2HMAC(
        algorithm=hashes.SHA256(),
        length=32,
        salt=salt,
        iterations=100000,
        backend=default_backend()
    )
    return kdf.derive(password.encode())

def aes_encrypt(plaintext: bytes, key: bytes, iv: bytes) -> bytes:
    """
    AES-CBC with PKCS7 padding.
    plaintext -> ciphertext
    """
    padder = sym_padding.PKCS7(128).padder()
    padded = padder.update(plaintext) + padder.finalize()

    cipher = Cipher(algorithms.AES(key), modes.CBC(iv))
    encryptor = cipher.encryptor()
    ciphertext = encryptor.update(padded) + encryptor.finalize()
    return ciphertext

def aes_decrypt(ciphertext: bytes, key: bytes, iv: bytes) -> bytes:
    """
    AES-CBC with PKCS7 unpadding.
    ciphertext -> plaintext
    """
    cipher = Cipher(algorithms.AES(key), modes.CBC(iv))
    decryptor = cipher.decryptor()
    padded = decryptor.update(ciphertext) + decryptor.finalize()

    unpadder = sym_padding.PKCS7(128).unpadder()
    try:
        plaintext = unpadder.update(padded) + unpadder.finalize()
        return plaintext
    except ValueError:
        # Padding error usually means wrong key
        raise ValueError("Invalid padding or incorrect key")

def send_email(subject, recipients, body):
    """
    Helper function to send simple emails.
    Returns (success, error_message)
    """
    if isinstance(recipients, str):
        recipients = [recipients]
    
    try:
        msg = Message(subject, recipients=recipients, body=body)
        mail.send(msg)
        print(f"Email sent to {recipients}: {subject}")
        return True, None
    except Exception as e:
        print(f"Failed to send email to {recipients}: {e}")
        return False, str(e)

# Routes

@app.route("/")
@login_required
def index():
    """
    After login, redirect based on role.
    """
    if current_user.role == "receiver":
        return redirect(url_for("receiver_dashboard"))
    else:
        return redirect(url_for("sender_dashboard"))

# --------------- Register ------------------------------

@app.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        name = request.form.get("name", "").strip()
        email = request.form.get("email", "").strip().lower()
        password = request.form.get("password", "")
        role = request.form.get("role", "sender").strip().lower()

        if not name or not email or not password:
            flash("Please fill in all fields.")
            return redirect(url_for("register"))

        if role not in ["sender", "receiver"]:
            role = "sender"

        existing = User.query.filter_by(email=email).first()
        if existing:
            flash("An account with this email already exists.")
            return redirect(url_for("register"))

        # No RSA key generation anymore

        hashed_password = generate_password_hash(password)

        user = User(
            name=name,
            email=email,
            password=hashed_password,
            role=role,
        )
        db.session.add(user)
        db.session.commit()

        flash("Registration successful. Please log in.")
        return redirect(url_for("login"))

    return render_template("register.html")

# --------------- Login --------------------------------

@app.route("/login", methods=["GET", "POST"])
def login():
    # If already logged in, send them to their dashboard
    if current_user.is_authenticated:
        if current_user.role == "receiver":
            return redirect(url_for("receiver_dashboard"))
        else:
            return redirect(url_for("sender_dashboard"))

    if request.method == "POST":
        name = request.form.get("name", "").strip()
        email = request.form.get("email", "").strip().lower()
        password = request.form.get("password", "")

        user = User.query.filter_by(email=email).first()

        if not user:
            flash("Invalid email, name, or password.")
            return redirect(url_for("login"))

        # Validate name (case-insensitive)
        if not user.name or user.name.strip().lower() != name.lower():
            flash("Invalid name for this account.")
            return redirect(url_for("login"))

        # Validate password
        if not check_password_hash(user.password, password):
            flash("Invalid email, name, or password.")
            return redirect(url_for("login"))

        # Login OK
        login_user(user)

        next_page = request.args.get("next")
        if user.role == "receiver":
            return redirect(next_page or url_for("receiver_dashboard"))
        else:
            return redirect(next_page or url_for("sender_dashboard"))

    return render_template("login.html")

# --------------- Logout -------------------------------

@app.route("/logout")
@login_required
def logout():
    logout_user()
    # clear any decrypted info from session
    session.pop("decrypted_text", None)
    session.pop("last_decrypted_item_id", None)
    session.pop("aes_key_hex", None)
    flash("You have been logged out.")
    return redirect(url_for("login"))

# --------------- Sender Dashboard ---------------------

@app.route("/sender_dashboard", methods=["GET", "POST"])
@login_required
def sender_dashboard():
    if current_user.role != "sender":
        return redirect(url_for("receiver_dashboard"))

    if request.method == "POST":
        file = request.files.get("file")
        text = request.form.get("text", "")
        encryption_password = request.form.get("encryption_password", "")

        if not file or not text or not encryption_password:
            flash("Please provide file, message, and an encryption password.")
            return redirect(url_for("sender_dashboard"))

        file_bytes = file.read()

        # 1. Generate Info for File Encryption
        aes_key = secrets.token_bytes(32)  # 256-bit key for the file
        file_iv = secrets.token_bytes(16)  # 128-bit IV for the file

        # 2. Encrypt file + text
        file_cipher = aes_encrypt(file_bytes, aes_key, file_iv)
        text_cipher = aes_encrypt(text.encode("utf-8"), aes_key, file_iv)

        # 3. Derive Key Encryption Key (KEK) from password
        salt = secrets.token_bytes(16)
        kek = derive_key(encryption_password, salt)

        # 4. Wrap the AES key using the KEK
        wrapping_iv = secrets.token_bytes(16)
        aes_key_wrapped = aes_encrypt(aes_key, kek, wrapping_iv)

        # 5. Store in DB
        record = EncryptedData(
            filename=file.filename,
            file_data=file_cipher,
            text_encrypted=text_cipher,
            aes_key_wrapped=aes_key_wrapped,
            salt=salt,
            wrapping_iv=wrapping_iv,
            iv=file_iv,
            sender=current_user,
        )
        db.session.add(record)
        db.session.commit()

        flash("File and message encrypted and stored successfully.")
        
        # --- Email Notification to Receivers ---
        try:
            # Find all users with role 'receiver'
            receivers = User.query.filter_by(role="receiver").all()
            receiver_emails = [r.email for r in receivers if r.email]
            
            if receiver_emails:
                subject = "New Secure File Available"
                body = (
                    f"Hello,\n\n"
                    f"A new file has been uploaded by {current_user.name} ({current_user.email}).\n"
                    f"Filename: {file.filename}\n\n"
                    f"Please log in to your dashboard to decrypt and view it.\n"
                )
                # Send email notification
                success, err_msg = send_email(subject, receiver_emails, body)
                if not success:
                    flash(f"Warning: Email notification failed. {err_msg}")

        except Exception as e:
            print(f"Error sending upload notification: {e}")
            flash(f"Error checking receivers for notification: {e}")

        return redirect(url_for("sender_dashboard"))

    return render_template("sender_dashboard.html")

# --------------- Receiver Dashboard -------------------

@app.route("/receiver_dashboard", methods=["GET", "POST"])
@login_required
def receiver_dashboard():
    if current_user.role != "receiver":
        return redirect(url_for("sender_dashboard"))

    if request.method == "POST":
        decryption_password = request.form.get("decryption_password", "")

        if not decryption_password:
            flash("Please enter the decryption password.")
            return redirect(url_for("receiver_dashboard"))

        # Get latest encrypted record
        item = EncryptedData.query.order_by(EncryptedData.created_at.desc()).first()
        if not item:
            flash("No encrypted data found.")
            return redirect(url_for("receiver_dashboard"))

        try:
            # 1. Derive KEK using the stored salt and provided password
            kek = derive_key(decryption_password, item.salt)

            # 2. Unwrap the AES key
            aes_key = aes_decrypt(item.aes_key_wrapped, kek, item.wrapping_iv)

            # 3. Decrypt text message
            plaintext_bytes = aes_decrypt(item.text_encrypted, aes_key, item.iv)
            plaintext = plaintext_bytes.decode("utf-8", errors="replace")

            # Save info to session (NOT full file bytes; only small data)
            session["decrypted_text"] = plaintext
            session["last_decrypted_item_id"] = item.id
            session["aes_key_hex"] = aes_key.hex()

            flash("Decryption successful.")

            # --- Email Notification to Sender ---
            try:
                # Notify the original sender that their file was decrypted
                sender = item.sender
                if sender and sender.email:
                    subject = "Your File Was Decrypted"
                    body = (
                        f"Hello {sender.name},\n\n"
                        f"Your file '{item.filename}' was successfully decrypted by {current_user.name} ({current_user.email}).\n"
                        f"Time: {datetime.utcnow()}\n"
                    )

                    success, err_msg = send_email(subject, sender.email, body)
                    if not success:
                        flash(f"Warning: Email notification failed. {err_msg}")
            except Exception as e:
                print(f"Error sending decryption notification: {e}")
                flash(f"Error notifying sender: {e}")
        except Exception as e:
            print("Decryption error:", e)
            session.pop("decrypted_text", None)
            session.pop("last_decrypted_item_id", None)
            session.pop("aes_key_hex", None)
            flash("Decryption failed. Incorrect password or data corrupted.")
            return redirect(url_for("receiver_dashboard"))

    decrypted_flag = "decrypted_text" in session
    return render_template("receiver_dashboard.html", decrypted=decrypted_flag)

# --------------- Download decrypted file --------------

@app.route("/download_decrypted_file")
@login_required
def download_decrypted_file():
    """
    Decrypt the file on the fly using AES key stored in session,
    and send it as a download.
    """
    item_id = session.get("last_decrypted_item_id")
    aes_key_hex = session.get("aes_key_hex")

    if not item_id or not aes_key_hex:
        flash("No decrypted file available. Please decrypt first.")
        return redirect(url_for("receiver_dashboard"))

    # Get encrypted record
    item = db.session.get(EncryptedData, int(item_id))
    if not item:
        flash("Encrypted data not found.")
        return redirect(url_for("receiver_dashboard"))

    try:
        aes_key = bytes.fromhex(aes_key_hex)
        decrypted_file_bytes = aes_decrypt(item.file_data, aes_key, item.iv)

        mem = BytesIO()
        mem.write(decrypted_file_bytes)
        mem.seek(0)

        filename = item.filename or "decrypted_file"
        return send_file(
            mem,
            as_attachment=True,
            download_name=filename,
            mimetype="application/octet-stream",
        )
    except Exception as e:
        print("File decrypt error:", e)
        flash("Unable to decrypt file for download.")
        return redirect(url_for("receiver_dashboard"))

# App start

if __name__ == "__main__":
    with app.app_context():
        db.create_all()
    app.run(debug=True)
